#ifndef SELF_DESTRUCTING_H
#define SELF_DESTRUCTING_H

#include <string>
#include <vector>
#include <ios>

class SelfDestructingMessage {

};

#endif

#pragma once

// If you have any classes or functions that you don't want to put in recipe.h or app.h, put them here.
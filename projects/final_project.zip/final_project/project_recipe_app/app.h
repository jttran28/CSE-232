#pragma once

#include <iostream>
using std::ostream; using std::endl;
#include <vector>
using std::vector;
#include <string>
using std::string;
#include <algorithm>
#include <iterator>

#include "recipe.h"
#include "utility.h"

class RecipeApp {
    private:
        vector<Recipe> recipes_;
        vector<Ingredient> pantry_;
    public:
        RecipeApp()=default;
        void AddRecipe(Recipe);
        Recipe UseUpIngredient(string);
        void AddIngredientToPantry(string);
        friend ostream& operator<<(ostream&, const RecipeApp&);
};

void RecipeApp::AddRecipe(Recipe r){
    recipes_.push_back(r);
    std::sort(recipes_.begin(),recipes_.end(),
    [](Recipe p1, Recipe p2){
        return p1.name() < p2.name();
    });
}
void RecipeApp::AddIngredientToPantry(string s){
    Ingredient ingrdt(s);
    pantry_.push_back(s);
    std::sort(pantry_.begin(),pantry_.end(),
    [](Ingredient p1, Ingredient p2){
        return p1.name < p2.name;
    });
}

/*
Lastly, this class should implement a member function named "UseUpIngredient" 
that accepts a string denoting the value, unit, and name of an ingredient. 
It should search the recipes (in order by name) and if the recipe uses that ingredient, 
it should return a copy of that recipe with the most amount of number of servings that 
the recipe can support with the indicated ingredient. 
If the recipe doesn't use that ingredient, throw a std::invalid_argument exception.
*/

Recipe RecipeApp::UseUpIngredient(string s){
    Ingredient new_ingrdt(s); // ingrdt using
    Recipe rcp;
    bool found;
    Ingredient ingrdt_this;
    ostringstream oss;
    for (Recipe r : recipes_) {
        for (size_t i = 0; i < r.ingrdt().size(); ++i) {
            Ingredient ingrdt = r.ingrdt().at(i);
            if (ingrdt.name == new_ingrdt.name){
                ingrdt_this = ingrdt;
                found = true;
                rcp = r;
                break;
            }
        }
    }
    if (found != true) {
        throw std::invalid_argument("Invalid argument");
    } 
    Fraction val = ingrdt_this.value;
    int i = 1;
    while (val.to_dec() < new_ingrdt.value.to_dec()) {
        val = ingrdt_this.value.multiply(i);
        ++i;
    }
    Recipe output(rcp.name(), rcp.srvgs());
    oss << val << " " << ingrdt_this.unit << " " << ingrdt_this.name;
    output.AddIngredient(oss.str());

    return output;
}

ostream& operator<<(ostream &out, const RecipeApp &r){
    out << "(Recipes in the app (ordered by name):\n";
    std::for_each(r.recipes_.begin(), r.recipes_.end(),
    [&out](Recipe rcp){
        out << rcp << endl;
    });
    out << "Ingredients in pantry (ordered by name):\n";
    std::for_each(r.pantry_.begin(), r.pantry_.end(),
    [&out](Ingredient ingrdt){
        out << ingrdt.value << " " << ingrdt.unit << " " << ingrdt.name << endl;
    });
    return out;
}
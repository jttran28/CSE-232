#pragma once

#include <string>
using std::string;
#include <sstream>
using std::ostringstream; using std::istringstream;
#include <vector>
using std::vector;
#include <algorithm>
#include <iterator>
#include <iostream>
using std::ostream;

class Fraction {
    private:
        int whole_num_ = 0;
        int dvdnd_ = 0;
        int dvsr_ = 1;
        string type_frac_;
    public:
        Fraction()=default;
        Fraction(const string&);
        Fraction(const int &num, const int &denom){
            dvdnd_ = num;
            dvsr_ = denom;
            if (dvdnd_ > dvsr_) {
                type_frac_ = "improper";
            } 
            type_frac_ = "normal";
        }
        Fraction(const int &num){
            whole_num_ = num;
            type_frac_ = "whole";
        }

        // accessors
        string type() const { return type_frac_; }
        void type(string typ) { type_frac_ = typ; }

        Fraction to_normal();
        double to_dec();
        Fraction divide(const int&);
        Fraction multiply(const int&);
        Fraction multiply(Fraction&);

        friend ostream& operator<<(ostream &out, const Fraction &f) {
            if (f.type_frac_ == "mixed") {
                out << f.whole_num_ + (f.dvdnd_/f.dvsr_) << '-' << (f.dvdnd_ % f.dvsr_) << '/' << f.dvsr_;
            } else if (f.type_frac_ == "improper") {
                out << (f.dvdnd_/f.dvsr_) << " " << (f.dvdnd_%f.dvsr_) << "/" << f.dvsr_;
            } else if  (f.type_frac_ == "normal" ) {
                out << f.dvdnd_ << "/" << f.dvsr_;
            } else {
                out << f.whole_num_;
            }
            return out;
        }
};

Fraction::Fraction(const string &s) {
    istringstream iss(s);
    char ch;
    if ((s.find('-') != string::npos) || (s.length() == 1)){
        iss >> whole_num_;
        iss.get(ch);
    } 
    iss >> dvdnd_;
    iss.get(ch);
    iss >> dvsr_;
    if (s.length() == 1) {
        type_frac_ = "whole";
    } else if (s.find('-') != string::npos) {
        type_frac_ = "mixed";
    } else if (((dvdnd_ % dvsr_) != 0) && (dvdnd_ > dvsr_)){
        type_frac_ = "improper";
    } else {
        type_frac_ = "normal";
    }
}

double Fraction::to_dec(){
    if (type_frac_ == "mixed") {
        return static_cast<double>(whole_num_) - (static_cast<double>(dvdnd_)/static_cast<double>(dvsr_));
    }
    return static_cast<double>(whole_num_) + (static_cast<double>(dvdnd_)/static_cast<double>(dvsr_));
}

Fraction Fraction::to_normal(){ // returns a (whether improper or not) fraction w/ normal type
    int num = (whole_num_*dvsr_) - dvdnd_;
    int denom = dvsr_;
    Fraction new_frac(num, denom);
    return new_frac;
}

Fraction Fraction::divide(const int &i){
    Fraction new_frac(dvdnd_, dvsr_*i);
    return new_frac;
}

Fraction Fraction::multiply(const int &i) {
    if (type_frac_ == "whole") {
        Fraction new_frac(whole_num_*i);
        return new_frac;
    } else if (type_frac_ == "mixed"){
        int num = i*dvsr_ - dvdnd_;
        Fraction new_frac(num, dvsr_);
        return new_frac;
    } else {
        Fraction new_frac(dvdnd_*i, dvsr_);
        return new_frac;
    }
}

// Fraction Fraction::multiply(Fraction &f) { // only works for same types;
//     Fraction f1 = this->to_normal();
//     Fraction f2 = f.to_normal();
//     Fraction new_frac(f1.dvdnd_*f2.dvdnd_, f1.dvsr_*f1.dvsr_);
//     return new_frac;
// }

struct Ingredient {
    string unit;
    string name;
    Fraction value;
    Ingredient()=default;
    Ingredient(string s){
        istringstream iss(s);
        string value_str;
        char ch;
        iss >> value_str;
        Fraction rvalue(value_str);
        value = rvalue;
        iss >> unit;
        iss.get(ch);
        getline(iss, name);
    }
};

void RemoveWhitespace(string &s){
    /*
    the following source helped me write this function to remove leading and trailing whitespace:
    https://www.techiedelight.com/trim-string-cpp-remove-leading-trailing-spaces/
    */
    auto it1 = std::find_if(s.begin(), s.end(), 
    [](auto &c){
        return (isspace(c) == false);
    });
    s.erase(s.begin(), it1);
    auto it2 = std::find_if(s.rbegin(), s.rend(), 
    [](auto &c){
        return (isspace(c) == false);
    });
    s.erase(it2.base(), s.end());
}
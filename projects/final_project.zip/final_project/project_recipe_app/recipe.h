#pragma once

#include <string>
using std::string;
#include <iostream>
using std::endl;
using std::ostream;
#include <sstream>
#include <stdexcept>
using std::istringstream;
using std::ostringstream;
#include <vector>
using std::vector;
#include <algorithm>

#include "utility.h"

class Recipe {
 private:
  string name_;
  int srvgs_;
  vector<Ingredient> ingredients_;
  vector<string> instructions_;

 public:
  // constructors
  Recipe() = default;
  Recipe(string, int);

  // accesors
  string name() const { return name_; }
  int srvgs() const { return srvgs_; }
  void srvgs(int s) { srvgs_ = s; }
  vector<Ingredient> ingrdt() const { return ingredients_; }
  vector<string> instrct() const { return instructions_; }

  // members
  void AddIngredient(string);
  void SetInstructions(string);
  string IngredientInOneServing(string);
  void ChangeServings(int);

  // friend
  friend ostream &operator<<(ostream &, const Recipe &);
};

Recipe::Recipe(string s, int i) {
  name_ = s;
  srvgs_ = i;
}

void Recipe::AddIngredient(string s) {
  Ingredient ingrdt(s);
  ingredients_.push_back(ingrdt);
}

void Recipe::SetInstructions(string s) {
  istringstream iss(s);
  string line;
  while (getline(iss, line)) {
    if (line == "") {
      continue;
    }
    RemoveWhitespace(line);
    instructions_.push_back(line);
  }
}

string Recipe::IngredientInOneServing(string s) {
  string output;
  ostringstream oss;
  auto it = std::find_if(
      ingredients_.begin(), ingredients_.end(),
      [&s](const Ingredient &ingrdt) { return (ingrdt.name == s); });
  if (it == ingredients_.end()) {
    throw std::invalid_argument("Invalid argument");
  }
  Ingredient ingrdt(*it);
  Fraction new_value = (ingrdt.value).divide(srvgs_);
  oss << new_value << " " << ingrdt.unit << " " << ingrdt.name;
  return oss.str();
}

void Recipe::ChangeServings(int n) {
  int change = abs(n - srvgs_);
  std::for_each(ingredients_.begin(), ingredients_.end(),
                [&change](Ingredient &ingrdt) {
                  ingrdt.value = ingrdt.value.multiply(change);
                });
  srvgs_ = n;
}

ostream &operator<<(ostream &out, const Recipe &r) {
  out << "Recipe for: " << r.name_ << endl;
  out << "Serves " << r.srvgs_;
  out << "\nIngredients:\n";
  std::for_each(
      r.ingredients_.begin(), r.ingredients_.end(), [&out](auto ingrdt) {
        out << ingrdt.value << " " << ingrdt.unit << " " << ingrdt.name << endl;
      });
  out << endl;
  out << "Instructions:\n";
  std::for_each(r.instructions_.begin(), r.instructions_.end(),
                [&out](const string &line) { out << line << endl; });
  return out;
}